import { useState } from "react";
import { NavLink, Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import { api } from "./api";
import { StatusDot } from "./components/ui";
import { NewPipelineDialog } from "./components/NewPipelineDialog";
import { useApp } from "./lib/store";
import Dashboard from "./pages/Dashboard";
import PipelinePage from "./pages/PipelinePage";
import RunPage from "./pages/RunPage";
import RunsPage from "./pages/RunsPage";

function Sidebar({ onNew }: { onNew: () => void }) {
  const { pipelines, health, refresh, toast } = useApp();
  const location = useLocation();
  const navigate = useNavigate();
  const pipelineId = location.pathname.startsWith("/p/") ? location.pathname.split("/")[2] : undefined;

  const sync = async () => {
    try {
      const list = await api.sync();
      await refresh();
      toast(`${list.length} pipeline(s) found`, "success");
    } catch (err) {
      toast((err as Error).message, "error");
    }
  };

  return (
    <aside className="flex min-h-0 flex-col border-r border-ink-600/50 bg-ink-900">
      <div className="flex items-center gap-2.5 px-4 pb-3 pt-4">
        <div className="grid h-[34px] w-[34px] place-items-center rounded-[9px] bg-gradient-to-br from-brand to-[#7f5bff] text-[17px] font-extrabold text-white">
          G
        </div>
        <div>
          <div className="font-bold tracking-tight">GraETL</div>
          <div className="text-[11px] text-fg-muted">
            {health ? `v${health.version} · ${health.active_runs} active` : "offline"}
          </div>
        </div>
      </div>

      <nav className="flex flex-col gap-0.5 px-2 pb-2">
        {[
          { to: "/", label: "Dashboard", icon: "▤", end: true },
          { to: "/runs", label: "Runs", icon: "⟳", end: false },
        ].map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              `flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] ${
                isActive ? "bg-brand-soft text-[#c9d9ff]" : "text-fg-dim hover:bg-ink-800 hover:text-fg"
              }`
            }
          >
            <span className="w-4 text-center opacity-80">{item.icon}</span>
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="flex items-center justify-between px-3.5 pb-1.5 pt-3 text-[11px] uppercase tracking-[0.09em] text-fg-muted">
        <span>Pipelines</span>
        <div className="flex gap-0.5">
          <button className="h-6 w-6 rounded-md hover:bg-ink-800 hover:text-fg" title="Rescan folder" onClick={sync}>
            ⟲
          </button>
          <button className="h-6 w-6 rounded-md hover:bg-ink-800 hover:text-fg" title="New pipeline" onClick={onNew}>
            ＋
          </button>
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-0.5 overflow-auto px-2 pb-2">
        {pipelines.length === 0 ? (
          <div className="px-3 py-4 text-center text-[13px] text-fg-muted">
            No pipelines yet.
            <button className="btn btn-primary btn-sm mt-3 w-full justify-center" onClick={onNew}>
              Create one
            </button>
          </div>
        ) : (
          pipelines.map((p) => {
            const status = p.active_run?.status ?? p.last_run?.status ?? "idle";
            return (
              <button
                key={p.id}
                onClick={() => navigate(`/p/${p.id}`)}
                className={`flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[13px] ${
                  pipelineId === p.id ? "bg-ink-700 text-fg" : "text-fg-dim hover:bg-ink-800 hover:text-fg"
                }`}
              >
                <StatusDot status={p.enabled ? status : "disabled"} />
                <span className="min-w-0 flex-1 truncate">{p.title}</span>
                <span className="font-mono text-[10px] text-fg-muted">
                  {p.definition_error ? "err" : p.stateful ? `${p.state_summary?.entities ?? 0}e` : "–"}
                </span>
              </button>
            );
          })
        )}
      </div>

      <div className="border-t border-ink-600/50 px-3.5 py-2.5 font-mono text-[11px] text-fg-muted">
        {health ? (
          <>
            <div title={health.database}>db · {health.database.split(/[\\/]/).slice(-2).join("/")}</div>
            <div>ui · {health.ui}</div>
          </>
        ) : (
          "server unreachable"
        )}
      </div>
    </aside>
  );
}

export default function App() {
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <div className="grid h-full grid-cols-1 md:grid-cols-[264px_1fr]">
      <div className="hidden md:block">
        <Sidebar onNew={() => setDialogOpen(true)} />
      </div>
      <main className="min-h-0 min-w-0 overflow-auto">
        <Routes>
          <Route path="/" element={<Dashboard onNew={() => setDialogOpen(true)} />} />
          <Route path="/runs" element={<RunsPage />} />
          <Route path="/runs/:runId" element={<RunPage />} />
          <Route path="/p/:pipelineId" element={<PipelinePage />} />
          <Route path="/p/:pipelineId/:tab" element={<PipelinePage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      {dialogOpen ? <NewPipelineDialog onClose={() => setDialogOpen(false)} /> : null}
    </div>
  );
}
