/* Typed client for the GraETL API. */

export type RunStatus =
  | "queued" | "starting" | "running" | "pausing" | "paused"
  | "stopping" | "succeeded" | "failed" | "stopped" | "crashed";

export const TERMINAL: RunStatus[] = ["succeeded", "failed", "stopped", "crashed"];
export const isActive = (s?: string | null) => !!s && !TERMINAL.includes(s as RunStatus);

export interface ModuleMeta {
  title?: string;
  description?: string;
  tags?: string[];
  owner?: string;
  graphs?: string[];
  graphlibs?: string[];
  [key: string]: unknown;
}

export interface ModuleDef {
  name: string;
  kind: "module";
  /** "python" today; "graph" once compiled node flows run. */
  source: string;
  version: number;
  /** Coarse stage: every lower layer must be up to date before this one runs. */
  execution_layer: number;
  depends_on: string[];
  /** Everything that must be up to date first: lower layers + depends_on. */
  requires: string[];
  title: string;
  description: string;
  /** File relative to the pipeline folder, e.g. "modules/vitals/load.module.py". */
  file: string | null;
  folder: string | null;
  meta: ModuleMeta;
  seq: number;
}

/** A .graph file: a module that runs once the node-flow runtime lands. */
export interface PendingModuleDef {
  name: string;
  file: string;
  source: "graph";
}

export interface TaskDef {
  name: string;
  kind: "task";
  source: string;
  version: number;
  phase: "pre" | "post";
  title: string;
  description: string;
  seq: number;
}

export interface PipelineFunctionDef {
  name: string;
  description: string;
}

export interface ModuleFolderDef {
  name: string;
  folder: string;
  has_python: boolean;
  modules: string[];
  graphs: string[];
  graph_modules: PendingModuleDef[];
  graphlibs: string[];
  meta: ModuleMeta;
  /** The folder holds .graph modules that cannot run yet. */
  pending: boolean;
}

export interface PipelineDefinition {
  id: string;
  title: string;
  description: string;
  stateful: boolean;
  tags: string[];
  execution: string;
  max_attempts: number;
  has_entity_source: boolean;
  layers: number[];
  modules: ModuleDef[];
  tasks: TaskDef[];
  functions: PipelineFunctionDef[];
  graphlibs: string[];
  module_folders: ModuleFolderDef[];
  pending_modules: PendingModuleDef[];
  config?: Record<string, unknown>;
}

export interface ModuleSummary {
  module: string;
  total: number;
  done?: number;
  pending?: number;
  running?: number;
  failed?: number;
  skipped?: number;
}

export interface Run {
  id: number;
  pipeline_id: string;
  parent_run_id: number | null;
  status: RunStatus;
  mode: string;
  trigger: string;
  params: Record<string, unknown>;
  pid: number | null;
  phase: string | null;
  progress_done: number;
  progress_total: number;
  metrics: RunMetrics;
  log_path: string | null;
  error: string | null;
  exit_code: number | null;
  created_at: string;
  started_at: string | null;
  finished_at: string | null;
  duration_ms: number | null;
  /** Last process telemetry sample stored for this run. */
  stats: ProcessStats;
  steps?: RunStep[];
}

export interface ProcessStats {
  pid?: number;
  rss_mb?: number;
  peak_rss_mb?: number;
  cpu_percent?: number;
  threads?: number;
  open_files?: number;
  entities_done?: number;
  entities_per_s?: number;
  elapsed_s?: number;
  parallel?: number;
  backend?: string;
  processed?: number;
  skipped?: number;
  failed?: number;
  entities_total?: number;
}

export interface RunMetrics {
  entities_total?: number;
  entities_new?: number;
  entities_changed?: number;
  work_items?: number;
  work_remaining?: number;
  processed?: number;
  skipped?: number;
  failed?: number;
  steps_run?: number;
  duration_ms?: number;
  counters?: Record<string, number>;
  module_state?: ModuleSummary[];
  entity_status?: Record<string, number>;
  waiting_for_upstream?: number;
  contended?: number;
  resources?: ProcessStats;
}

export interface RunStep {
  run_id: number;
  step: string;
  kind: string;
  version: number;
  status: string;
  selected: number;
  processed: number;
  skipped: number;
  failed: number;
  duration_ms: number;
  error: string | null;
  started_at: string | null;
  finished_at: string | null;
  metrics: Record<string, unknown>;
}

export interface Pipeline {
  id: string;
  title: string;
  description: string | null;
  folder: string;
  stateful: boolean;
  enabled: boolean;
  tags: string[];
  definition: PipelineDefinition | null;
  definition_error: string | null;
  active_run: Run | null;
  last_run: Run | null;
  stats: { runs_considered: number; success_rate: number | null; avg_duration_ms: number | null };
  state_summary?: { entities: number; modules: ModuleSummary[]; statuses: Record<string, number> };
}

export interface EntityModuleState {
  entity_id: string;
  module: string;
  module_version: number;
  status: string;
  source_updated_at: string | null;
  processed_source_updated_at: string | null;
  processed_at: string | null;
  attempts: number;
  duration_ms: number | null;
  error: string | null;
  result: unknown;
}

export interface EntityRow {
  entity_id: string;
  label: string | null;
  source_updated_at: string | null;
  payload: Record<string, unknown>;
  discovered_at: string;
  last_seen_at: string;
  deleted_at: string | null;
  modules: EntityModuleState[];
}

export interface Overview {
  pipelines: Pipeline[];
  recent_runs: Run[];
  active_runs: Run[];
  counts: { pipelines: number; stateful: number; running: number; failing: number };
}

export interface Health {
  ok: boolean;
  version: string;
  root: string;
  pipelines_dir: string;
  database: string;
  active_runs: number;
  ui: string;
  /** A copy of Monaco is vendored into the install; load it from /vendor/vs. */
  monaco_vendored: boolean;
  /** Where else to load Monaco from; "" means stay offline. */
  monaco_url: string;
  time: string;
}

export interface RunEvent {
  kind: string;
  ts: string;
  level?: string;
  message?: string;
  step?: string;
  source?: string;
  status?: string;
  entity_id?: string;
  duration_ms?: number;
  processed?: number;
  skipped?: number;
  failed?: number;
  selected?: number;
  error?: string | null;
  done?: number;
  total?: number;
  mode?: string;
  path?: string;
  top?: string;
  run?: Run;
  events?: RunEvent[];
}

async function request<T>(path: string, init?: RequestInit & { json?: unknown }): Promise<T> {
  const { json, ...rest } = init ?? {};
  const res = await fetch(path, {
    ...rest,
    headers: { "Content-Type": "application/json", ...(rest.headers ?? {}) },
    body: json !== undefined ? JSON.stringify(json) : rest.body,
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) {
    const detail = data?.detail;
    if (detail && typeof detail === "object" && detail.detail) {
      // A save rejected for a syntax error carries the offending position.
      const error = new Error(String(detail.detail)) as Error & { syntax_error?: unknown };
      error.syntax_error = detail.syntax_error ?? null;
      throw error;
    }
    throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail ?? res.statusText));
  }
  return data as T;
}

export const api = {
  health: () => request<Health>("/api/health"),
  overview: () => request<Overview>("/api/overview"),
  pipelines: () => request<Pipeline[]>("/api/pipelines"),
  pipeline: (id: string) => request<Pipeline>(`/api/pipelines/${encodeURIComponent(id)}`),
  sync: () => request<Pipeline[]>("/api/pipelines/sync", { method: "POST", json: {} }),
  createPipeline: (body: { id: string; title?: string | null; description?: string; template: string }) =>
    request<Pipeline>("/api/pipelines", { method: "POST", json: body }),
  createModule: (
    id: string,
    body: { name: string; title?: string | null; folder?: string | null; execution_layer?: number },
  ) => request<Pipeline>(`/api/pipelines/${encodeURIComponent(id)}/modules`, { method: "POST", json: body }),
  setEnabled: (id: string, enabled: boolean) =>
    request<Pipeline>(`/api/pipelines/${encodeURIComponent(id)}`, { method: "PATCH", json: { enabled } }),
  deletePipeline: (id: string, deleteFiles: boolean) =>
    request<{ ok: boolean }>(`/api/pipelines/${encodeURIComponent(id)}?delete_files=${deleteFiles}`, {
      method: "DELETE",
    }),
  files: (id: string) =>
    request<{ path: string; type: string; size: number | null; editable: boolean }[]>(
      `/api/pipelines/${encodeURIComponent(id)}/files`,
    ),
  file: (id: string, path: string) =>
    request<{ path: string; content: string }>(
      `/api/pipelines/${encodeURIComponent(id)}/file?path=${encodeURIComponent(path)}`,
    ),
  saveFile: (id: string, path: string, content: string) =>
    request<Pipeline>(`/api/pipelines/${encodeURIComponent(id)}/file?path=${encodeURIComponent(path)}`, {
      method: "PUT",
      json: { content },
    }),
  entities: (
    id: string,
    params: {
      limit?: number;
      offset?: number;
      search?: string;
      status?: string;
      module?: string;
      order?: string;
    } = {},
  ) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v !== undefined && v !== "" && qs.set(k, String(v)));
    return request<{
      total: number;
      matching: number;
      limit: number;
      offset: number;
      entities: EntityRow[];
      modules: ModuleSummary[];
      statuses: Record<string, number>;
    }>(`/api/pipelines/${encodeURIComponent(id)}/entities?${qs}`);
  },
  entity: (id: string, entityId: string) =>
    request<EntityRow>(
      `/api/pipelines/${encodeURIComponent(id)}/entities/${encodeURIComponent(entityId)}`,
    ),
  resetEntity: (id: string, entityId: string, module: string | null) =>
    request<{ ok: boolean; reset: number; entity: EntityRow }>(
      `/api/pipelines/${encodeURIComponent(id)}/entities/${encodeURIComponent(entityId)}/reset`,
      { method: "POST", json: { module } },
    ),
  createFile: (id: string, path: string, content = "") =>
    request<{ ok: boolean; path: string }>(
      `/api/pipelines/${encodeURIComponent(id)}/file/new`,
      { method: "POST", json: { path, content } },
    ),
  checkFile: (id: string, path: string, content: string) =>
    request<{ ok: boolean; error: { message: string; line: number; column: number } | null }>(
      `/api/pipelines/${encodeURIComponent(id)}/file/check?path=${encodeURIComponent(path)}`,
      { method: "POST", json: { content } },
    ),
  resetState: (id: string, body: { module?: string | null; drop_entities?: boolean }) =>
    request<{ ok: boolean; reset: number }>(`/api/pipelines/${encodeURIComponent(id)}/state/reset`, {
      method: "POST",
      json: body,
    }),
  runs: (params: { pipeline_id?: string; limit?: number } = {}) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v !== undefined && qs.set(k, String(v)));
    return request<Run[]>(`/api/runs?${qs}`);
  },
  pipelineRuns: (id: string, limit = 100) =>
    request<Run[]>(`/api/pipelines/${encodeURIComponent(id)}/runs?limit=${limit}`),
  run: (runId: number) => request<Run>(`/api/runs/${runId}`),
  steps: (runId: number) => request<RunStep[]>(`/api/runs/${runId}/steps`),
  console: (runId: number, limit = 2000) =>
    request<{ run_id: number; status: RunStatus; events: RunEvent[] }>(
      `/api/runs/${runId}/console?limit=${limit}`,
    ),
  startRun: (
    id: string,
    body: {
      mode?: string;
      steps?: string[];
      entity_ids?: string[];
      profile?: boolean;
      debug?: boolean;
      parallel?: number;
      limit_entities?: number;
      sample?: "first" | "random";
    },
  ) =>
    request<Run>(`/api/pipelines/${encodeURIComponent(id)}/runs`, { method: "POST", json: body }),
  control: (runId: number, action: "pause" | "resume" | "stop", force = false) =>
    request<Run>(`/api/runs/${runId}/${action}${force ? "?force=true" : ""}`, { method: "POST", json: {} }),
};

export function wsUrl(path: string): string {
  const proto = location.protocol === "https:" ? "wss:" : "ws:";
  return `${proto}//${location.host}${path}`;
}
