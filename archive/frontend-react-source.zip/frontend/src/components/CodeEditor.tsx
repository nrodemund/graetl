/* Monaco, wired to the GraETL palette.
 *
 * Where Monaco itself comes from follows the server: a copy vendored into the
 * install (/vendor/vs) wins, otherwise [ui] monaco_url from graetl.toml. Both
 * are reported by /api/health, so an air-gapped install works as long as
 * `graetl vendor-monaco` has been run.
 */

import Editor, { loader, type Monaco } from "@monaco-editor/react";
import type { editor } from "monaco-editor";
import { useEffect, useRef } from "react";
import { useApp } from "../lib/store";

export interface SyntaxProblem {
  message: string;
  line: number;
  column: number;
}

const LANGUAGES: Record<string, string> = {
  py: "python",
  toml: "ini",
  ini: "ini",
  json: "json",
  graph: "json",
  graphlib: "json",
  md: "markdown",
  sql: "sql",
  yaml: "yaml",
  yml: "yaml",
};

export function languageFor(path: string | null): string {
  const ext = (path ?? "").split(".").pop()?.toLowerCase() ?? "";
  return LANGUAGES[ext] ?? "plaintext";
}

let configured = false;

function defineTheme(monaco: Monaco) {
  monaco.editor.defineTheme("graetl-dark", {
    base: "vs-dark",
    inherit: true,
    rules: [
      { token: "comment", foreground: "6b7487", fontStyle: "italic" },
      { token: "keyword", foreground: "c792ea" },
      { token: "string", foreground: "8bd49c" },
      { token: "number", foreground: "f0b866" },
      { token: "type", foreground: "4dd0e1" },
      { token: "function", foreground: "5b8cff" },
    ],
    colors: {
      "editor.background": "#0b0f17",
      "editor.foreground": "#d7deea",
      "editorLineNumber.foreground": "#4a5265",
      "editorLineNumber.activeForeground": "#8b95a8",
      "editorGutter.background": "#0b0f17",
      "editor.lineHighlightBackground": "#141a26",
      "editor.selectionBackground": "#2c3a4a",
      "editorCursor.foreground": "#5b8cff",
      "editorWidget.background": "#161f30",
      "editorWidget.border": "#223049",
    },
  });
}

export function CodeEditor({
  path,
  value,
  onChange,
  onSave,
  problem,
  readOnly,
  height = "60vh",
}: {
  path: string | null;
  value: string;
  onChange: (value: string) => void;
  onSave: () => void;
  problem?: SyntaxProblem | null;
  readOnly?: boolean;
  height?: string;
}) {
  const { health } = useApp();
  const editorRef = useRef<editor.IStandaloneCodeEditor | null>(null);
  const monacoRef = useRef<Monaco | null>(null);
  // Monaco's command closures are captured once, so route the save through a ref.
  const saveRef = useRef(onSave);
  saveRef.current = onSave;

  if (!configured && health) {
    configured = true;
    const base = health.monaco_vendored ? "/vendor/vs" : health.monaco_url;
    if (base) loader.config({ paths: { vs: base } });
  }

  // Server-reported syntax errors become squiggles on the offending line.
  useEffect(() => {
    const ed = editorRef.current;
    const monaco = monacoRef.current;
    const model = ed?.getModel();
    if (!ed || !monaco || !model) return;
    if (!problem) {
      monaco.editor.setModelMarkers(model, "graetl", []);
      return;
    }
    const line = Math.min(Math.max(problem.line || 1, 1), model.getLineCount());
    monaco.editor.setModelMarkers(model, "graetl", [
      {
        severity: monaco.MarkerSeverity.Error,
        message: problem.message,
        startLineNumber: line,
        startColumn: Math.max(problem.column || 1, 1),
        endLineNumber: line,
        endColumn: model.getLineMaxColumn(line),
      },
    ]);
    ed.revealLineInCenter(line);
  }, [problem]);

  return (
    <div className="overflow-hidden rounded-lg border border-ink-600/60" style={{ height }}>
      <Editor
        height="100%"
        theme="graetl-dark"
        path={path ?? "untitled"}
        language={languageFor(path)}
        value={value}
        onChange={(next) => onChange(next ?? "")}
        loading={<div className="p-4 text-sm text-fg-muted">Loading the editor…</div>}
        beforeMount={defineTheme}
        onMount={(ed, monaco) => {
          editorRef.current = ed;
          monacoRef.current = monaco;
          ed.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, () => saveRef.current());
        }}
        options={{
          readOnly,
          fontSize: 13,
          fontFamily: "ui-monospace, SFMono-Regular, 'JetBrains Mono', Consolas, monospace",
          tabSize: 4,
          insertSpaces: true,
          minimap: { enabled: true, renderCharacters: false, maxColumn: 90 },
          rulers: [100],
          scrollBeyondLastLine: false,
          smoothScrolling: true,
          bracketPairColorization: { enabled: true },
          guides: { bracketPairs: true, indentation: true },
          renderWhitespace: "selection",
          padding: { top: 10, bottom: 10 },
          fixedOverflowWidgets: true,
        }}
      />
    </div>
  );
}
