import { useEffect, useMemo, useRef, useState } from "react";
import type { RunEvent } from "../api";
import { fmtClock, fmtDuration } from "../lib/format";

const LEVELS = ["debug", "info", "success", "warning", "error", "event"] as const;
type Level = (typeof LEVELS)[number];

const LEVEL_CLASS: Record<string, string> = {
  debug: "text-fg-muted",
  info: "text-[#cfd9ea]",
  success: "text-ok",
  warning: "text-warn",
  error: "text-err",
  event: "text-brand",
};

interface Line {
  level: Level;
  tag: string;
  msg: string;
  ts?: string;
}

export function eventToLine(event: RunEvent): Line | null {
  switch (event.kind) {
    case "log":
      return {
        level: (event.level as Level) ?? "info",
        tag: event.step ?? event.source ?? "",
        msg: event.message ?? "",
        ts: event.ts,
      };
    case "entity":
      return {
        level: event.status === "failed" ? "error" : "debug",
        tag: event.step ?? "",
        ts: event.ts,
        msg: `${event.entity_id}: ${event.status}${
          event.duration_ms !== undefined ? ` (${event.duration_ms} ms)` : ""
        }${event.error ? ` — ${event.error}` : ""}`,
      };
    case "step_start":
      return {
        level: "event",
        tag: "step",
        ts: event.ts,
        msg: `▶ ${event.step}${event.selected ? ` — ${event.selected} item(s)` : ""}`,
      };
    case "step_end":
      return {
        level: event.status === "failed" ? "error" : "event",
        tag: "step",
        ts: event.ts,
        msg: `■ ${event.step}: ${event.status} · processed ${event.processed ?? 0}, skipped ${
          event.skipped ?? 0
        }, failed ${event.failed ?? 0} · ${fmtDuration(event.duration_ms)}`,
      };
    case "run_start":
      return { level: "event", tag: "run", ts: event.ts, msg: `▶ run started (mode ${event.mode})` };
    case "run_end":
      return {
        level: event.status === "succeeded" ? "success" : "error",
        tag: "run",
        ts: event.ts,
        msg: `■ run ${event.status}${event.error ? ` — ${event.error}` : ""}`,
      };
    case "status":
      return { level: "event", tag: "run", ts: event.ts, msg: `run ${event.status}` };
    case "profile":
      return { level: "info", tag: "profile", ts: event.ts, msg: `profile → ${event.path}\n${event.top ?? ""}` };
    default:
      return null;
  }
}

export function Console({ events, downloadUrl }: { events: RunEvent[]; downloadUrl: string }) {
  const [enabled, setEnabled] = useState<Set<Level>>(
    () => new Set<Level>(["info", "success", "warning", "error", "event"]),
  );
  const [filter, setFilter] = useState("");
  const [follow, setFollow] = useState(true);
  const boxRef = useRef<HTMLDivElement>(null);

  const lines = useMemo(() => {
    const needle = filter.toLowerCase();
    return events
      .map(eventToLine)
      .filter((line): line is Line => !!line && enabled.has(line.level))
      .filter((line) => !needle || `${line.msg} ${line.tag}`.toLowerCase().includes(needle));
  }, [events, enabled, filter]);

  useEffect(() => {
    if (follow && boxRef.current) boxRef.current.scrollTop = boxRef.current.scrollHeight;
  }, [lines.length, follow]);

  const toggle = (level: Level) =>
    setEnabled((current) => {
      const next = new Set(current);
      if (next.has(level)) next.delete(level);
      else next.add(level);
      return next;
    });

  return (
    <div className="flex h-[min(60vh,640px)] min-h-[320px] flex-col">
      <div className="flex flex-wrap items-center gap-2 border-b border-ink-600/60 bg-ink-800 px-3 py-2">
        {LEVELS.map((level) => (
          <button
            key={level}
            onClick={() => toggle(level)}
            className={`rounded-md border px-2 py-1 text-[11px] ${
              enabled.has(level)
                ? "border-[#2c4a8f] bg-brand-soft text-[#c9d9ff]"
                : "border-ink-600 bg-ink-900 text-fg-muted"
            }`}
          >
            {level}
          </button>
        ))}
        <input
          className="input w-40 py-1 text-xs"
          placeholder="filter…"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        />
        <div className="flex-1" />
        <label className="flex items-center gap-1.5 text-xs text-fg-dim">
          <input type="checkbox" checked={follow} onChange={(e) => setFollow(e.target.checked)} /> follow
        </label>
        <a className="btn btn-sm" href={downloadUrl}>
          Download
        </a>
      </div>
      <div ref={boxRef} className="flex-1 overflow-auto bg-[#070a11] py-2.5 font-mono text-[12.5px] leading-[1.55]">
        {lines.length === 0 ? (
          <div className="px-4 py-8 text-center text-fg-muted">Waiting for output…</div>
        ) : (
          lines.map((line, index) => (
            <div key={index} className="flex gap-2.5 whitespace-pre-wrap break-words px-3.5 py-px hover:bg-[#0d121c]">
              <span className="shrink-0 text-[#44506a]">{fmtClock(line.ts)}</span>
              <span className={`w-20 shrink-0 ${line.level === "event" ? "text-brand" : "text-fg-muted"}`}>
                {line.tag}
              </span>
              <span className={`min-w-0 flex-1 ${LEVEL_CLASS[line.level]}`}>{line.msg}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
