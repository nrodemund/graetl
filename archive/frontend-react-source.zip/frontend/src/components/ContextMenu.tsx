/* Right-click menus.
 *
 * `useContextMenu()` gives you an `open(event, items)` to call from
 * onContextMenu and a `<menu.node />` to render once per page.
 */

import { useCallback, useEffect, useState, type MouseEvent, type ReactNode } from "react";

export interface MenuItem {
  label: ReactNode;
  hint?: string;
  onSelect: () => void;
  danger?: boolean;
  disabled?: boolean;
}

export type MenuEntry = MenuItem | null;

interface MenuState {
  x: number;
  y: number;
  items: MenuEntry[];
}

export function useContextMenu() {
  const [menu, setMenu] = useState<MenuState | null>(null);

  const open = useCallback((event: MouseEvent, items: MenuEntry[]) => {
    event.preventDefault();
    event.stopPropagation();
    if (!items.some(Boolean)) return;
    setMenu({ x: event.clientX, y: event.clientY, items });
  }, []);

  const close = useCallback(() => setMenu(null), []);

  useEffect(() => {
    if (!menu) return;
    const dismiss = () => setMenu(null);
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setMenu(null);
    window.addEventListener("mousedown", dismiss);
    window.addEventListener("blur", dismiss);
    window.addEventListener("resize", dismiss);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("mousedown", dismiss);
      window.removeEventListener("blur", dismiss);
      window.removeEventListener("resize", dismiss);
      window.removeEventListener("keydown", onKey);
    };
  }, [menu]);

  const node = menu ? (
    <div
      className="fixed z-[90] min-w-[230px] rounded-xl border border-ink-600 bg-ink-800 p-1.5 shadow-[0_16px_44px_#000a]"
      style={{
        left: Math.min(menu.x, window.innerWidth - 250),
        top: Math.min(menu.y, window.innerHeight - menu.items.length * 34 - 20),
      }}
      onMouseDown={(e) => e.stopPropagation()}
    >
      {menu.items.map((item, index) =>
        item === null ? (
          <div key={`sep-${index}`} className="mx-1.5 my-1 h-px bg-ink-600/60" />
        ) : (
          <button
            key={index}
            disabled={item.disabled}
            onClick={() => {
              setMenu(null);
              item.onSelect();
            }}
            className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-left text-[13px] disabled:cursor-not-allowed disabled:text-fg-muted ${
              item.danger ? "text-err hover:bg-err/10" : "text-fg hover:bg-brand/15"
            } disabled:hover:bg-transparent`}
          >
            <span className="flex-1">{item.label}</span>
            {item.hint ? <span className="font-mono text-[11px] text-fg-muted">{item.hint}</span> : null}
          </button>
        ),
      )}
    </div>
  ) : null;

  return { open, close, node };
}
