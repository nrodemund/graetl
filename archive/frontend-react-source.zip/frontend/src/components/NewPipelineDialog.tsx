import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api";
import { useApp } from "../lib/store";

export function NewPipelineDialog({ onClose }: { onClose: () => void }) {
  const { refresh, toast } = useApp();
  const navigate = useNavigate();
  const [id, setId] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [template, setTemplate] = useState("stateful");
  const [busy, setBusy] = useState(false);

  const create = async () => {
    if (!id.trim()) {
      toast("An id is required", "error");
      return;
    }
    setBusy(true);
    try {
      await api.createPipeline({ id: id.trim(), title: title.trim() || null, description, template });
      await refresh();
      toast(`Pipeline ${id} created`, "success");
      onClose();
      navigate(`/p/${id.trim()}/files`);
    } catch (err) {
      toast((err as Error).message, "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-5"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="w-full max-w-lg rounded-xl border border-ink-600 bg-ink-900 shadow-2xl">
        <div className="border-b border-ink-600/60 px-5 py-3.5 font-semibold">New pipeline</div>
        <div className="flex flex-col gap-3 px-5 py-4">
          <label className="flex flex-col gap-1.5 text-xs text-fg-dim">
            Pipeline id (folder name)
            <input className="input" value={id} onChange={(e) => setId(e.target.value)} placeholder="icu_admissions" />
          </label>
          <label className="flex flex-col gap-1.5 text-xs text-fg-dim">
            Title
            <input
              className="input"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="ICU Admissions"
            />
          </label>
          <label className="flex flex-col gap-1.5 text-xs text-fg-dim">
            Description
            <input className="input" value={description} onChange={(e) => setDescription(e.target.value)} />
          </label>
          <label className="flex flex-col gap-1.5 text-xs text-fg-dim">
            Template
            <select className="input" value={template} onChange={(e) => setTemplate(e.target.value)}>
              <option value="stateful">Stateful — entity state, resumable</option>
              <option value="stateless">Stateless — ordered tasks only</option>
              <option value="empty">Empty — nothing yet</option>
            </select>
          </label>
        </div>
        <div className="flex justify-end gap-2 border-t border-ink-600/60 px-5 py-3">
          <button className="btn" onClick={onClose}>
            Cancel
          </button>
          <button className="btn btn-primary" onClick={create} disabled={busy}>
            Create
          </button>
        </div>
      </div>
    </div>
  );
}
