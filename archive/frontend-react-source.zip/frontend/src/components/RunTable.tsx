import { useNavigate } from "react-router-dom";
import type { Run } from "../api";
import { isActive } from "../api";
import { fmtDuration, fmtNumber, relTime } from "../lib/format";
import { Empty, ProgressBar, StatusPill } from "./ui";

export function RunTable({ runs, showPipeline }: { runs: Run[]; showPipeline?: boolean }) {
  const navigate = useNavigate();
  if (!runs.length) return <Empty>No runs yet.</Empty>;

  return (
    <table className="w-full text-[13px]">
      <thead>
        <tr>
          <th className="th">Run</th>
          {showPipeline ? <th className="th">Pipeline</th> : null}
          <th className="th">Status</th>
          <th className="th">Mode</th>
          <th className="th">Progress</th>
          <th className="th num">Processed</th>
          <th className="th num">Failed</th>
          <th className="th num">Duration</th>
          <th className="th">Finished</th>
        </tr>
      </thead>
      <tbody>
        {runs.map((run) => {
          const metrics = run.metrics ?? {};
          const pct = run.progress_total
            ? Math.round((run.progress_done / run.progress_total) * 100)
            : isActive(run.status)
              ? 0
              : 100;
          return (
            <tr
              key={run.id}
              className="cursor-pointer hover:bg-ink-800"
              onClick={() => navigate(`/runs/${run.id}`)}
            >
              <td className="td font-mono">#{run.id}</td>
              {showPipeline ? <td className="td">{run.pipeline_id}</td> : null}
              <td className="td">
                <StatusPill status={run.status} />
              </td>
              <td className="td text-fg-muted">{run.mode}</td>
              <td className="td">
                <ProgressBar
                  value={pct}
                  tone={run.status === "failed" ? "err" : run.status === "succeeded" ? "ok" : undefined}
                />
              </td>
              <td className="td num">{fmtNumber(metrics.processed ?? 0)}</td>
              <td className={`td num ${metrics.failed ? "text-err" : ""}`}>{fmtNumber(metrics.failed ?? 0)}</td>
              <td className="td num text-fg-muted">{fmtDuration(run.duration_ms)}</td>
              <td className="td text-fg-muted">
                {run.finished_at ? relTime(run.finished_at) : run.started_at ? "running" : "queued"}
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}
