import type { ReactNode } from "react";

const DOT: Record<string, string> = {
  running: "bg-run animate-pulseDot",
  queued: "bg-brand",
  starting: "bg-brand",
  succeeded: "bg-ok",
  failed: "bg-err",
  crashed: "bg-err",
  paused: "bg-pause",
  pausing: "bg-pause",
  stopped: "bg-warn",
  stopping: "bg-warn",
  done: "bg-ok",
  pending: "bg-brand",
  skipped: "bg-warn",
  idle: "bg-fg-muted",
  disabled: "bg-ink-500",
};

const PILL: Record<string, string> = {
  running: "text-run border-[#14414a] bg-[#0d2a30]",
  succeeded: "text-ok border-[#14452f] bg-[#0f2a20]",
  done: "text-ok border-[#14452f] bg-[#0f2a20]",
  failed: "text-err border-[#4a1f22] bg-[#2a1316]",
  crashed: "text-err border-[#4a1f22] bg-[#2a1316]",
  paused: "text-pause border-[#392a55] bg-[#1d1630]",
  pausing: "text-pause border-[#392a55] bg-[#1d1630]",
  stopped: "text-warn border-[#4a3a17] bg-[#2a220f]",
  stopping: "text-warn border-[#4a3a17] bg-[#2a220f]",
  skipped: "text-warn border-[#4a3a17] bg-[#2a220f]",
  queued: "text-brand border-[#223a6b] bg-[#101a33]",
  starting: "text-brand border-[#223a6b] bg-[#101a33]",
  pending: "text-brand border-[#223a6b] bg-[#101a33]",
};

export function StatusDot({ status }: { status: string }) {
  return <span className={`inline-block h-2 w-2 shrink-0 rounded-full ${DOT[status] ?? "bg-fg-muted"}`} />;
}

export function StatusPill({ status, label }: { status: string; label?: string }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-semibold
        ${PILL[status] ?? "text-fg-dim border-ink-600 bg-ink-700"}`}
    >
      <StatusDot status={status} />
      {label ?? status}
    </span>
  );
}

export function Tag({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border border-ink-600 bg-ink-700 px-2.5 py-0.5 text-[11px] text-fg-muted">
      {children}
    </span>
  );
}

export function StatCard({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  tone?: "ok" | "err" | "run";
}) {
  const color = tone === "err" ? "text-err" : tone === "run" ? "text-run" : tone === "ok" ? "text-ok" : "";
  return (
    <div className="panel px-4 py-3.5">
      <div className="text-[11px] uppercase tracking-[0.08em] text-fg-muted">{label}</div>
      <div className={`mt-1 text-2xl font-bold tabular-nums ${color}`}>{value}</div>
      {hint ? <div className="mt-1.5 text-xs text-fg-muted">{hint}</div> : null}
    </div>
  );
}

export function Panel({
  title,
  actions,
  children,
  flush,
}: {
  title?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  flush?: boolean;
}) {
  return (
    <div className="panel mb-4">
      {title ? (
        <div className="panel-head">
          <span>{title}</span>
          <div className="flex-1" />
          {actions}
        </div>
      ) : null}
      <div className={flush ? "overflow-x-auto" : "p-4"}>{children}</div>
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="px-4 py-8 text-center text-[13px] text-fg-muted">{children}</div>;
}

export function ProgressBar({ value, tone }: { value: number; tone?: "ok" | "err" }) {
  const color = tone === "err" ? "bg-err" : tone === "ok" ? "bg-ok" : "bg-brand";
  return (
    <div className="h-1.5 min-w-[90px] overflow-hidden rounded-full bg-ink-700">
      <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${Math.min(100, value)}%` }} />
    </div>
  );
}

export function Banner({ children, tone = "error" }: { children: ReactNode; tone?: "error" | "info" }) {
  return tone === "error" ? (
    <div className="mb-4 whitespace-pre-wrap rounded-lg border border-[#4a1f22] bg-[#2a1316] px-4 py-2.5 font-mono text-xs text-[#ffc9c9]">
      {children}
    </div>
  ) : (
    <div className="mb-4 rounded-lg border border-[#223a6b] bg-[#101a33] px-4 py-2.5 text-[13px] text-[#cfe0ff]">
      {children}
    </div>
  );
}
