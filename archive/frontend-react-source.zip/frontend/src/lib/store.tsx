import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { api, wsUrl, type Health, type Pipeline } from "../api";

interface Toast {
  id: number;
  message: string;
  kind: "info" | "success" | "error";
}

interface AppState {
  pipelines: Pipeline[];
  health: Health | null;
  refresh: () => Promise<void>;
  toast: (message: string, kind?: Toast["kind"]) => void;
  /** Bumped whenever the server reports a run or pipeline change. */
  revision: number;
}

const Ctx = createContext<AppState | null>(null);

export function useApp(): AppState {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useApp must be used inside <AppProvider>");
  return ctx;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [pipelines, setPipelines] = useState<Pipeline[]>([]);
  const [health, setHealth] = useState<Health | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [revision, setRevision] = useState(0);
  const nextId = useRef(1);

  const toast = useCallback((message: string, kind: Toast["kind"] = "info") => {
    const id = nextId.current++;
    setToasts((all) => [...all, { id, message, kind }]);
    setTimeout(() => setToasts((all) => all.filter((t) => t.id !== id)), 4500);
  }, []);

  const refresh = useCallback(async () => {
    try {
      setPipelines(await api.pipelines());
    } catch (err) {
      toast((err as Error).message, "error");
    }
  }, [toast]);

  useEffect(() => {
    void refresh();
    api.health().then(setHealth).catch(() => setHealth(null));
    const timer = setInterval(() => {
      api.health().then(setHealth).catch(() => setHealth(null));
    }, 15000);
    return () => clearInterval(timer);
  }, [refresh]);

  // Global event stream: keeps the sidebar and every open page current.
  useEffect(() => {
    let socket: WebSocket | null = null;
    let closed = false;
    let retry: ReturnType<typeof setTimeout> | undefined;
    let poll: ReturnType<typeof setInterval> | undefined;

    const connect = () => {
      if (closed) return;
      try {
        socket = new WebSocket(wsUrl("/api/ws/system"));
      } catch {
        poll = setInterval(() => setRevision((r) => r + 1), 5000);
        return;
      }
      socket.onmessage = (event) => {
        const data = JSON.parse(event.data);
        if (data.kind === "hello") return;
        setRevision((r) => r + 1);
        void refresh();
      };
      socket.onclose = () => {
        if (!closed) retry = setTimeout(connect, 3000);
      };
    };
    connect();
    return () => {
      closed = true;
      if (retry) clearTimeout(retry);
      if (poll) clearInterval(poll);
      socket?.close();
    };
  }, [refresh]);

  const value = useMemo<AppState>(
    () => ({ pipelines, health, refresh, toast, revision }),
    [pipelines, health, refresh, toast, revision],
  );

  return (
    <Ctx.Provider value={value}>
      {children}
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`max-w-sm rounded-lg border border-ink-600 bg-ink-700 px-4 py-2.5 text-[13px] shadow-xl
              border-l-[3px] ${
                t.kind === "error" ? "border-l-err" : t.kind === "success" ? "border-l-ok" : "border-l-brand"
              }`}
          >
            {t.message}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}
