import { useEffect, useState, type MouseEvent } from "react";
import { useNavigate } from "react-router-dom";
import { api, type Overview, type Pipeline } from "../api";
import { RunTable } from "../components/RunTable";
import { Empty, Panel, StatCard, StatusPill, Tag } from "../components/ui";
import { fmtDuration, fmtNumber, relTime } from "../lib/format";
import { useApp } from "../lib/store";

function PipelineTable({ pipelines }: { pipelines: Pipeline[] }) {
  const navigate = useNavigate();
  const { toast } = useApp();
  if (!pipelines.length) return <Empty>No pipelines found. Create one to get started.</Empty>;

  const run = async (event: MouseEvent, id: string) => {
    event.stopPropagation();
    try {
      const started = await api.startRun(id, { mode: "incremental" });
      toast(`Run #${started.id} started`, "success");
      navigate(`/runs/${started.id}`);
    } catch (err) {
      toast((err as Error).message, "error");
    }
  };

  return (
    <table className="w-full text-[13px]">
      <thead>
        <tr>
          <th className="th">Pipeline</th>
          <th className="th">Type</th>
          <th className="th num">Steps</th>
          <th className="th num">Entities</th>
          <th className="th">Status</th>
          <th className="th">Last run</th>
          <th className="th num">Duration</th>
          <th className="th" />
        </tr>
      </thead>
      <tbody>
        {pipelines.map((p) => {
          const def = p.definition;
          const steps = (def?.modules.length ?? 0) + (def?.tasks.length ?? 0);
          const status = p.active_run?.status ?? p.last_run?.status ?? "idle";
          return (
            <tr key={p.id} className="cursor-pointer hover:bg-ink-800" onClick={() => navigate(`/p/${p.id}`)}>
              <td className="td">
                <div className="font-semibold">{p.title}</div>
                <div className="font-mono text-[11px] text-fg-muted">{p.id}</div>
              </td>
              <td className="td">
                {p.definition_error ? (
                  <StatusPill status="failed" label="broken" />
                ) : (
                  <Tag>{p.stateful ? "stateful" : "stateless"}</Tag>
                )}
              </td>
              <td className="td num">{steps}</td>
              <td className="td num">{p.stateful ? fmtNumber(p.state_summary?.entities ?? 0) : "–"}</td>
              <td className="td">{status === "idle" ? <Tag>idle</Tag> : <StatusPill status={status} />}</td>
              <td className="td text-fg-muted">{relTime(p.last_run?.finished_at)}</td>
              <td className="td num text-fg-muted">{fmtDuration(p.last_run?.duration_ms)}</td>
              <td className="td">
                <button
                  className={`btn btn-sm ${p.active_run ? "" : "btn-primary"}`}
                  disabled={!!p.active_run || !p.enabled}
                  onClick={(e) => run(e, p.id)}
                >
                  Run
                </button>
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}

export default function Dashboard({ onNew }: { onNew: () => void }) {
  const { revision, toast, refresh } = useApp();
  const [data, setData] = useState<Overview | null>(null);

  useEffect(() => {
    api.overview().then(setData).catch((err) => toast((err as Error).message, "error"));
  }, [revision, toast]);

  const sync = async () => {
    try {
      await api.sync();
      await refresh();
      setData(await api.overview());
      toast("Pipelines folder rescanned", "success");
    } catch (err) {
      toast((err as Error).message, "error");
    }
  };

  const counts = data?.counts;

  return (
    <div className="max-w-[1400px] px-6 pb-10 pt-6">
      <header className="mb-5 flex flex-wrap items-start gap-4">
        <div>
          <h1 className="mb-1 text-xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-[13px] text-fg-muted">Orchestrate, run and observe your ETL pipelines.</p>
        </div>
        <div className="flex-1" />
        <div className="flex gap-2">
          <button className="btn" onClick={sync}>
            Rescan folder
          </button>
          <button className="btn btn-primary" onClick={onNew}>
            New pipeline
          </button>
        </div>
      </header>

      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Pipelines" value={counts?.pipelines ?? "–"} />
        <StatCard label="Stateful" value={counts?.stateful ?? "–"} />
        <StatCard label="Active runs" value={counts?.running ?? 0} tone={counts?.running ? "run" : undefined} />
        <StatCard label="Last run failed" value={counts?.failing ?? 0} tone={counts?.failing ? "err" : undefined} />
      </div>

      <Panel title="Pipelines" flush>
        <PipelineTable pipelines={data?.pipelines ?? []} />
      </Panel>

      <Panel title="Recent runs" flush>
        <RunTable runs={data?.recent_runs ?? []} showPipeline />
      </Panel>
    </div>
  );
}
