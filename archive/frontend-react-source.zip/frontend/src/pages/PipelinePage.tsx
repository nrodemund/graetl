import { Fragment, useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api, type EntityRow, type Pipeline, type PipelineDefinition, type Run } from "../api";
import { CodeEditor, type SyntaxProblem } from "../components/CodeEditor";
import { useContextMenu, type MenuEntry } from "../components/ContextMenu";
import { RunTable } from "../components/RunTable";
import { Banner, Empty, Panel, StatCard, StatusPill, Tag } from "../components/ui";
import { fmtBytes, fmtDuration, fmtNumber, fmtTime, relTime } from "../lib/format";
import { useApp } from "../lib/store";

const TABS = ["overview", "runs", "entities", "files"] as const;
type Tab = (typeof TABS)[number];

/* ------------------------------------------------------------- module folders */

function ModuleFolders({
  def,
  onOpenFile,
}: {
  def: PipelineDefinition | null;
  onOpenFile: (path: string | null, what?: string) => void;
}) {
  const folders = def?.module_folders ?? [];
  const functions = def?.functions ?? [];
  const graphlibs = def?.graphlibs ?? [];
  const fileOf = Object.fromEntries((def?.modules ?? []).map((m) => [m.name, m.file]));
  if (!folders.length && !functions.length && !graphlibs.length) return null;

  return (
    <Panel
      title={
        <span>
          Module folders{" "}
          <span className="ml-2 font-mono text-xs font-normal text-fg-muted">
            pipelines/{def?.id}/modules/
          </span>
        </span>
      }
    >
      {folders.length ? (
        <div className="-mx-4 mb-4 overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr>
                <th className="th">Folder</th>
                <th className="th">Contains</th>
                <th className="th">Defines</th>
                <th className="th num">.graph</th>
                <th className="th num">.graphlib</th>
                <th className="th">Owner</th>
              </tr>
            </thead>
            <tbody>
              {folders.map((folder) => {
                const first = folder.modules.map((name) => fileOf[name]).find(Boolean) ?? null;
                return (
                <tr
                  key={folder.folder}
                  className={first ? "cursor-pointer hover:bg-ink-800" : undefined}
                  title={first ? `Double-click to edit ${first}` : "No python module in this folder"}
                  onDoubleClick={() => onOpenFile(first, folder.folder)}
                >
                  <td className="td font-mono">{folder.folder}/</td>
                  <td className="td">
                    <div className="flex flex-wrap gap-1">
                      {folder.modules.length ? <Tag>{folder.modules.length} .module.py</Tag> : null}
                      {folder.graph_modules.length ? (
                        <StatusPill status="skipped" label={`${folder.graph_modules.length} .graph`} />
                      ) : null}
                    </div>
                  </td>
                  <td className="td font-mono text-fg-muted">
                    {[...folder.modules, ...folder.graph_modules.map((g) => `${g.name} (graph)`)].join(
                      ", ",
                    ) || "–"}
                  </td>
                  <td className="td num">{folder.graphs.length}</td>
                  <td className="td num">{folder.graphlibs.length}</td>
                  <td className="td text-fg-muted">{String(folder.meta?.owner ?? "")}</td>
                </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : null}

      {functions.length ? (
        <>
          <div className="mb-1.5 text-xs text-fg-muted">
            Shared functions — callable from modules via <code>ctx.fn()</code>, and from node graphs
          </div>
          <div className="flex flex-wrap gap-1.5">
            {functions.map((fn) => (
              <span key={fn.name} title={fn.description}>
                <Tag>{fn.name}</Tag>
              </span>
            ))}
          </div>
        </>
      ) : null}

      {graphlibs.length ? (
        <>
          <div className="mb-1.5 mt-3 text-xs text-fg-muted">Pipeline-wide graph libraries</div>
          <div className="flex flex-wrap gap-1.5">
            {graphlibs.map((lib) => (
              <Tag key={lib}>{lib}</Tag>
            ))}
          </div>
        </>
      ) : null}
    </Panel>
  );
}

/* ------------------------------------------------------------------ overview */

function Overview({
  pipeline,
  onRun,
  onOpenFile,
  onResetModule,
}: {
  pipeline: Pipeline;
  onRun: (body: Parameters<typeof api.startRun>[1]) => void;
  onOpenFile: (path: string | null, what?: string) => void;
  onResetModule: (module: string) => void;
}) {
  const menu = useContextMenu();
  const busy = !!pipeline.active_run;
  const def = pipeline.definition;

  const moduleMenu = (name: string, file: string | null): MenuEntry[] => [
    { label: "▶ Run this module", hint: "pending", disabled: busy, onSelect: () => onRun({ steps: [name] }) },
    {
      label: "🐞 Debug run",
      hint: "one entity",
      disabled: busy,
      onSelect: () =>
        onRun({ mode: "full", steps: [name], limit_entities: 1, sample: "random", debug: true }),
    },
    {
      label: "⏱ Profile run",
      hint: "sample",
      disabled: busy,
      onSelect: () =>
        onRun({ mode: "full", steps: [name], limit_entities: 25, sample: "random", profile: true }),
    },
    null,
    { label: "✎ Edit source", hint: "double-click", disabled: !file, onSelect: () => onOpenFile(file, name) },
    { label: "⧉ Copy module name", onSelect: () => void navigator.clipboard?.writeText(name) },
    null,
    {
      label: "↺ Reset this module's state",
      danger: true,
      disabled: busy,
      onSelect: () => onResetModule(name),
    },
  ];
  const summary = pipeline.state_summary;
  const byModule = Object.fromEntries((summary?.modules ?? []).map((m) => [m.module, m]));
  const last = pipeline.last_run;
  const counters: Record<string, number> = last?.metrics?.counters ?? {};

  return (
    <>
      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Last run"
          value={last ? <StatusPill status={last.status} /> : <span className="text-fg-muted text-base">never run</span>}
          hint={last ? relTime(last.finished_at) : undefined}
        />
        <StatCard
          label="Success rate"
          value={
            pipeline.stats?.success_rate === null || pipeline.stats?.success_rate === undefined
              ? "–"
              : `${Math.round(pipeline.stats.success_rate * 100)}%`
          }
          hint={`last ${pipeline.stats?.runs_considered ?? 0} run(s)`}
        />
        <StatCard
          label="Avg duration"
          value={<span className="text-base">{fmtDuration(pipeline.stats?.avg_duration_ms)}</span>}
        />
        {pipeline.stateful ? (
          <StatCard
            label="Entities"
            value={fmtNumber(summary?.entities ?? 0)}
            hint={
              last?.metrics?.work_remaining !== undefined ? `${last.metrics.work_remaining} item(s) pending` : undefined
            }
          />
        ) : null}
      </div>

      {pipeline.description ? <Panel>{pipeline.description}</Panel> : null}

      {menu.node}

      <Panel
        title={
          <span>
            Steps{" "}
            <span className="ml-2 text-xs font-normal text-fg-muted">
              double-click a module to edit its code · right-click for actions
            </span>
          </span>
        }
        flush
      >
        {(def?.tasks.length ?? 0) + (def?.modules.length ?? 0) === 0 ? (
          <Empty>This pipeline has no steps yet — a run will succeed immediately.</Empty>
        ) : (
          <table className="w-full text-[13px]">
            <thead>
              <tr>
                <th className="th">Step</th>
                <th className="th">Kind</th>
                <th className="th num">Version</th>
                <th className="th num">Layer</th>
                <th className="th">Requires</th>
                <th className="th num">Done</th>
                <th className="th num">Pending</th>
                <th className="th num">Failed</th>
                <th className="th">Description</th>
                <th className="th" />
              </tr>
            </thead>
            <tbody>
              {def?.tasks.map((task) => (
                <tr key={`t-${task.name}`}>
                  <td className="td font-mono">{task.name}</td>
                  <td className="td">
                    <Tag>task · {task.phase}</Tag>
                  </td>
                  <td className="td num">v{task.version}</td>
                  <td className="td num text-fg-muted">–</td>
                  <td className="td text-fg-muted">–</td>
                  <td className="td num text-fg-muted">–</td>
                  <td className="td num text-fg-muted">–</td>
                  <td className="td num text-fg-muted">–</td>
                  <td className="td text-fg-muted">{task.description}</td>
                  <td className="td">
                    <button className="btn btn-sm" onClick={() => onRun({ steps: [task.name] })}>
                      ▶
                    </button>
                  </td>
                </tr>
              ))}
              {def?.modules.map((module) => {
                const stats = byModule[module.name];
                const graphs = module.meta?.graphs ?? [];
                return (
                  <tr
                    key={`m-${module.name}`}
                    className="cursor-pointer hover:bg-ink-800"
                    title={`Double-click to edit ${module.file ?? module.name} · right-click for actions`}
                    onDoubleClick={(e) => {
                      if ((e.target as HTMLElement).closest("button")) return;
                      onOpenFile(module.file, module.name);
                    }}
                    onContextMenu={(e) => menu.open(e, moduleMenu(module.name, module.file))}
                  >
                    <td className="td font-mono">
                      {module.name}
                      {module.file ? (
                        <div className="text-[11px] text-fg-muted">{module.file}</div>
                      ) : null}
                    </td>
                    <td className="td">
                      <div className="flex flex-wrap gap-1">
                        <Tag>module</Tag>
                        {graphs.length ? <Tag>{graphs.length} graph</Tag> : null}
                      </div>
                    </td>
                    <td className="td num">v{module.version}</td>
                    <td className="td num">{module.execution_layer}</td>
                    <td className="td font-mono text-fg-muted">
                      {(module.requires ?? module.depends_on).join(", ") || "–"}
                    </td>
                    <td className="td num">{fmtNumber(stats?.done ?? 0)}</td>
                    <td className="td num">{fmtNumber((stats?.pending ?? 0) + (stats?.running ?? 0))}</td>
                    <td className={`td num ${stats?.failed ? "text-err" : ""}`}>{fmtNumber(stats?.failed ?? 0)}</td>
                    <td className="td text-fg-muted">{module.description}</td>
                    <td className="td">
                      <div className="flex gap-1">
                        <button
                          className="btn btn-sm"
                          title="Run this module for every pending entity"
                          onClick={() => onRun({ steps: [module.name] })}
                        >
                          ▶
                        </button>
                        <button
                          className="btn btn-sm"
                          title="Debug run: one random entity, ctx.debug() on"
                          onClick={() =>
                            onRun({
                              mode: "full",
                              steps: [module.name],
                              limit_entities: 1,
                              sample: "random",
                              debug: true,
                            })
                          }
                        >
                          🐞
                        </button>
                        <button
                          className="btn btn-sm"
                          title="Profile run over 25 random entities"
                          onClick={() =>
                            onRun({
                              mode: "full",
                              steps: [module.name],
                              limit_entities: 25,
                              sample: "random",
                              profile: true,
                            })
                          }
                        >
                          ⏱
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {(def?.pending_modules ?? []).map((graph) => (
                <tr key={`g-${graph.name}`} className="opacity-60">
                  <td className="td font-mono">
                    {graph.name}
                    <div className="text-[11px] text-fg-muted">{graph.file}</div>
                  </td>
                  <td className="td">
                    <StatusPill status="skipped" label="graph" />
                  </td>
                  <td className="td num text-fg-muted">–</td>
                  <td className="td num text-fg-muted">–</td>
                  <td className="td text-fg-muted">–</td>
                  <td className="td num text-fg-muted">–</td>
                  <td className="td num text-fg-muted">–</td>
                  <td className="td num text-fg-muted">–</td>
                  <td className="td text-fg-muted">Node-flow module — not executable yet</td>
                  <td className="td" />
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Panel>

      <ModuleFolders def={def} onOpenFile={onOpenFile} />

      {Object.keys(counters).length ? (
        <Panel title={`Metrics of run #${last?.id}`}>
          <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {Object.entries(counters).map(([key, value]) => (
              <StatCard key={key} label={key} value={<span className="text-base">{fmtNumber(value)}</span>} />
            ))}
          </div>
        </Panel>
      ) : null}

      {last?.error ? <Banner>{last.error}</Banner> : null}
    </>
  );
}

/* ------------------------------------------------------------------ entities */

function Entities({ pipeline }: { pipeline: Pipeline }) {
  const { toast } = useApp();
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [moduleFilter, setModuleFilter] = useState("");
  const [limit, setLimit] = useState(100);
  const [offset, setOffset] = useState(0);
  const [rows, setRows] = useState<EntityRow[]>([]);
  const [matching, setMatching] = useState(0);
  const [total, setTotal] = useState(0);
  const [statuses, setStatuses] = useState<Record<string, number>>({});
  const [open, setOpen] = useState<string | null>(null);
  const modules = pipeline.definition?.modules ?? [];

  const load = useCallback(async () => {
    try {
      const data = await api.entities(pipeline.id, {
        limit,
        offset,
        search,
        status,
        module: moduleFilter,
      });
      setRows(data.entities);
      setMatching(data.matching);
      setTotal(data.total);
      setStatuses(data.statuses ?? {});
    } catch (err) {
      toast((err as Error).message, "error");
    }
  }, [pipeline.id, limit, offset, search, status, moduleFilter, toast]);

  useEffect(() => {
    const timer = setTimeout(() => void load(), 200);
    return () => clearTimeout(timer);
  }, [load]);

  const reset = async (entityId: string, module: string | null) => {
    try {
      const res = await api.resetEntity(pipeline.id, entityId, module);
      toast(`Reset ${res.reset} state row(s)`, "success");
      void load();
    } catch (err) {
      toast((err as Error).message, "error");
    }
  };

  const debugEntity = async (entityId: string, module: string) => {
    try {
      const run = await api.startRun(pipeline.id, {
        mode: "full",
        steps: [module],
        entity_ids: [entityId],
        debug: true,
      });
      toast(`Debug run #${run.id} started`, "success");
    } catch (err) {
      toast((err as Error).message, "error");
    }
  };

  const from = matching ? offset + 1 : 0;
  const to = Math.min(offset + limit, matching);

  return (
    <Panel
      title={
        <span>
          Entities <span className="ml-2 font-normal text-fg-muted">{fmtNumber(total)} known</span>
        </span>
      }
      actions={
        <div className="flex flex-wrap gap-2">
          <input
            className="input py-1 text-xs"
            placeholder="Search id or label…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setOffset(0);
            }}
          />
          <select
            className="input py-1 text-xs"
            value={moduleFilter}
            onChange={(e) => {
              setModuleFilter(e.target.value);
              setOffset(0);
            }}
          >
            <option value="">all modules</option>
            {modules.map((m) => (
              <option key={m.name} value={m.name}>
                {m.name}
              </option>
            ))}
          </select>
          <select
            className="input py-1 text-xs"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              setOffset(0);
            }}
          >
            <option value="">any state</option>
            {Object.entries(statuses).map(([key, count]) => (
              <option key={key} value={key}>
                {key} ({count})
              </option>
            ))}
          </select>
        </div>
      }
      flush
    >
      {rows.length === 0 ? (
        <Empty>No entity matches these filters.</Empty>
      ) : (
        <table className="w-full text-[13px]">
          <thead>
            <tr>
              <th className="th">Entity</th>
              <th className="th">Label</th>
              <th className="th">Source revision</th>
              {modules.map((m) => (
                <th key={m.name} className="th">
                  {m.name}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => {
              const byModule = Object.fromEntries(row.modules.map((m) => [m.module, m]));
              return (
                <Fragment key={row.entity_id}>
                  <tr
                    className="cursor-pointer hover:bg-ink-800"
                    onClick={() => setOpen(open === row.entity_id ? null : row.entity_id)}
                  >
                    <td className="td font-mono">{row.entity_id}</td>
                    <td className="td text-fg-muted">{row.label}</td>
                    <td className="td font-mono text-fg-muted">{row.source_updated_at ?? "–"}</td>
                    {modules.map((m) => {
                      const state = byModule[m.name];
                      if (!state)
                        return (
                          <td key={m.name} className="td">
                            <Tag>–</Tag>
                          </td>
                        );
                      const stale =
                        state.processed_source_updated_at &&
                        row.source_updated_at &&
                        state.processed_source_updated_at < row.source_updated_at;
                      return (
                        <td key={m.name} className="td" title={state.error ?? undefined}>
                          <StatusPill status={state.status} label={stale ? "stale" : state.status} />
                        </td>
                      );
                    })}
                  </tr>
                  {open === row.entity_id ? (
                    <tr>
                      <td className="td bg-ink-900" colSpan={3 + modules.length}>
                        <div className="mb-2 text-xs text-fg-muted">
                          first seen {fmtTime(row.discovered_at)} · last seen{" "}
                          {fmtTime(row.last_seen_at)}
                        </div>
                        <table className="w-full text-[12px]">
                          <thead>
                            <tr>
                              <th className="th">Module</th>
                              <th className="th">State</th>
                              <th className="th num">v</th>
                              <th className="th">Processed revision</th>
                              <th className="th">Processed at</th>
                              <th className="th num">Try</th>
                              <th className="th" />
                            </tr>
                          </thead>
                          <tbody>
                            {row.modules.map((m) => (
                              <tr key={m.module} title={m.error ?? undefined}>
                                <td className="td font-mono">{m.module}</td>
                                <td className="td">
                                  <StatusPill status={m.status} />
                                </td>
                                <td className="td num">{m.module_version}</td>
                                <td className="td font-mono text-fg-muted">
                                  {m.processed_source_updated_at ?? "–"}
                                </td>
                                <td className="td text-fg-muted">{fmtTime(m.processed_at)}</td>
                                <td className="td num">{m.attempts}</td>
                                <td className="td">
                                  <div className="flex gap-1">
                                    <button
                                      className="btn btn-sm"
                                      title="Debug run for this entity"
                                      onClick={() => debugEntity(row.entity_id, m.module)}
                                    >
                                      Debug
                                    </button>
                                    <button
                                      className="btn btn-sm"
                                      title="Forget this module's state"
                                      onClick={() => reset(row.entity_id, m.module)}
                                    >
                                      Reset
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {row.modules
                          .filter((m) => m.error)
                          .map((m) => (
                            <Banner key={m.module}>
                              {m.module}: {m.error}
                            </Banner>
                          ))}
                      </td>
                    </tr>
                  ) : null}
                </Fragment>
              );
            })}
          </tbody>
        </table>
      )}

      <div className="flex flex-wrap items-center gap-2 border-t border-ink-600/60 px-4 py-2.5 text-xs text-fg-muted">
        <span>
          {fmtNumber(from)}–{fmtNumber(to)} of {fmtNumber(matching)}
          {matching !== total ? ` matching · ${fmtNumber(total)} total` : ""}
        </span>
        <div className="flex-1" />
        <select
          className="input py-1 text-xs"
          value={limit}
          onChange={(e) => {
            setLimit(Number(e.target.value));
            setOffset(0);
          }}
        >
          {[50, 100, 250, 500].map((n) => (
            <option key={n} value={n}>
              {n} per page
            </option>
          ))}
        </select>
        <button className="btn btn-sm" disabled={!offset} onClick={() => setOffset(0)}>
          « First
        </button>
        <button
          className="btn btn-sm"
          disabled={!offset}
          onClick={() => setOffset(Math.max(0, offset - limit))}
        >
          ‹ Prev
        </button>
        <button className="btn btn-sm" disabled={to >= matching} onClick={() => setOffset(offset + limit)}>
          Next ›
        </button>
      </div>
    </Panel>
  );
}

/* --------------------------------------------------------------------- files */

function Files({
  pipeline,
  file,
  onSelect,
}: {
  pipeline: Pipeline;
  file: string | null;
  onSelect: (path: string | null) => void;
}) {
  const { toast, refresh } = useApp();
  const menu = useContextMenu();
  const [files, setFiles] = useState<{ path: string; type: string; size: number | null; editable: boolean }[]>([]);
  const [content, setContent] = useState("");
  const [saved, setSaved] = useState("");
  const [problem, setProblem] = useState<SyntaxProblem | null>(null);
  const [openTabs, setOpenTabs] = useState<string[]>([]);
  const active = !!pipeline.active_run;
  const dirty = content !== saved;

  useEffect(() => {
    api.files(pipeline.id).then(setFiles);
  }, [pipeline.id]);

  // Nothing chosen yet: start on pipeline.py, the file people edit most.
  useEffect(() => {
    if (file || !files.length) return;
    const editable = files.filter((f) => f.editable);
    onSelect(editable.find((f) => f.path === "pipeline.py")?.path ?? editable[0]?.path ?? null);
  }, [file, files, onSelect]);

  useEffect(() => {
    if (!file) return;
    api.file(pipeline.id, file).then((data) => {
      setContent(data.content);
      setSaved(data.content);
      setProblem(null);
      setOpenTabs((tabs) => [...tabs.filter((t) => t !== file), file].slice(-8));
    });
  }, [pipeline.id, file]);

  const select = (path: string) => {
    if (path === file) return;
    if (dirty && !window.confirm(`${file} has unsaved changes. Discard them?`)) return;
    onSelect(path);
  };

  const save = async () => {
    if (!file) return;
    if (active) {
      toast("Cannot save while a run is active", "error");
      return;
    }
    try {
      await api.saveFile(pipeline.id, file, content);
      setSaved(content);
      setProblem(null);
      toast(`Saved ${file}`, "success");
      await refresh();
    } catch (err) {
      const detail = err as Error & { syntax_error?: SyntaxProblem };
      setProblem(detail.syntax_error ?? null);
      toast(detail.message, "error");
    }
  };

  const check = async () => {
    if (!file) return;
    try {
      const res = await api.checkFile(pipeline.id, file, content);
      setProblem(res.error);
      toast(
        res.ok ? "No syntax errors" : `${res.error?.message} (line ${res.error?.line})`,
        res.ok ? "success" : "error",
      );
    } catch (err) {
      toast((err as Error).message, "error");
    }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[250px_1fr]">
      {menu.node}
      <Panel title="Files">
        <div className="flex max-h-[60vh] flex-col gap-px overflow-auto">
          {files.map((entry) => (
            <button
              key={entry.path}
              disabled={!entry.editable}
              onClick={() => select(entry.path)}
              onContextMenu={(e) =>
                entry.editable &&
                menu.open(e, [
                  { label: "✎ Open in the editor", onSelect: () => select(entry.path) },
                  { label: "⧉ Copy path", onSelect: () => void navigator.clipboard?.writeText(entry.path) },
                ])
              }
              className={`flex justify-between gap-2 rounded-md px-2.5 py-1.5 text-left font-mono text-xs ${
                entry.path === file
                  ? "bg-ink-700 text-fg"
                  : entry.editable
                    ? "text-fg-dim hover:bg-ink-800 hover:text-fg"
                    : "text-fg-muted"
              }`}
            >
              <span className="truncate">{entry.path}</span>
              <span className="text-fg-muted">{entry.type === "dir" ? "" : fmtBytes(entry.size)}</span>
            </button>
          ))}
        </div>
      </Panel>

      <Panel
        title={
          <span className="font-mono">
            {file ?? "no file"}
            {dirty ? <span className="ml-2 text-warn">● unsaved</span> : null}
          </span>
        }
        actions={
          <div className="flex gap-2">
            <button className="btn btn-sm" onClick={check} disabled={!file}>
              Check
            </button>
            <button className="btn btn-sm btn-primary" onClick={save} disabled={!file || !dirty || active}>
              Save
            </button>
          </div>
        }
      >
        {openTabs.length > 1 ? (
          <div className="-mt-1 mb-2 flex gap-px overflow-x-auto">
            {openTabs.map((path) => (
              <button
                key={path}
                onClick={() => select(path)}
                title={path}
                className={`whitespace-nowrap border-b-2 px-3 py-1.5 font-mono text-xs ${
                  path === file
                    ? "border-brand text-fg"
                    : "border-transparent text-fg-muted hover:text-fg"
                }`}
              >
                {path.split("/").pop()}
              </button>
            ))}
          </div>
        ) : null}

        <CodeEditor
          path={file}
          value={content}
          onChange={setContent}
          onSave={save}
          problem={problem}
          readOnly={active}
        />
        <p className="mt-2 text-xs text-fg-muted">
          Ctrl+S saves · saving re-reads the pipeline definition
          {active ? " · a run is active, so saving is disabled" : ""}.
        </p>
      </Panel>
    </div>
  );
}

/* ---------------------------------------------------------------------- page */

export default function PipelinePage() {
  const { pipelineId, tab } = useParams();
  const navigate = useNavigate();
  const { toast, refresh, revision } = useApp();
  const [pipeline, setPipeline] = useState<Pipeline | null>(null);
  const [runs, setRuns] = useState<Run[]>([]);
  /** Which file the Files tab shows - set from anywhere, e.g. by
      double-clicking a module on the Overview tab. */
  const [editorFile, setEditorFile] = useState<string | null>(null);
  const activeTab: Tab = (TABS as readonly string[]).includes(tab ?? "") ? (tab as Tab) : "overview";

  useEffect(() => {
    if (!pipelineId) return;
    api.pipeline(pipelineId).then(setPipeline).catch((err) => toast((err as Error).message, "error"));
  }, [pipelineId, revision, toast]);

  useEffect(() => {
    if (!pipelineId || activeTab !== "runs") return;
    api.pipelineRuns(pipelineId).then(setRuns).catch(() => undefined);
  }, [pipelineId, activeTab, revision]);

  if (!pipeline) return <div className="px-6 py-8 text-fg-muted">Loading {pipelineId}…</div>;

  const def = pipeline.definition;
  const active = pipeline.active_run;
  const paused = active?.status === "paused" || active?.status === "pausing";

  const runWith = async (body: Parameters<typeof api.startRun>[1]) => {
    if (active) {
      toast("A run is already active", "error");
      return;
    }
    try {
      const run = await api.startRun(pipeline.id, body);
      toast(`Run #${run.id} started`, "success");
      navigate(`/runs/${run.id}`);
    } catch (err) {
      toast((err as Error).message, "error");
    }
  };

  const start = (mode: string) => runWith({ mode });

  // A plain function on purpose: everything below the `!pipeline` early return
  // above runs conditionally, so a hook here would change the hook count
  // between renders (React error #310).
  const openFile = (path: string | null, what?: string) => {
    if (!path) {
      toast(`${what ?? "This step"} has no editable source file`, "error");
      return;
    }
    setEditorFile(path);
    navigate(`/p/${pipelineId}/files`);
  };

  const resetModule = async (module: string) => {
    if (
      !window.confirm(
        `Forget everything ${module} has processed?\n\nThe next run reprocesses every entity for this module. Data the module wrote is untouched.`,
      )
    )
      return;
    try {
      const res = await api.resetState(pipeline.id, { module });
      toast(`Reset ${res.reset} state row(s) for ${module}`, "success");
      await refresh();
    } catch (err) {
      toast((err as Error).message, "error");
    }
  };

  const control = async (action: "pause" | "resume" | "stop") => {
    if (!active) return;
    try {
      await api.control(active.id, action);
      toast(`Run ${action} requested`);
      setTimeout(() => void refresh(), 500);
    } catch (err) {
      toast((err as Error).message, "error");
    }
  };

  const toggleEnabled = async () => {
    try {
      const updated = await api.setEnabled(pipeline.id, !pipeline.enabled);
      setPipeline(updated);
      await refresh();
    } catch (err) {
      toast((err as Error).message, "error");
    }
  };

  return (
    <div className="max-w-[1400px] px-6 pb-10 pt-6">
      <header className="mb-4 flex flex-wrap items-start gap-4">
        <div>
          <h1 className="mb-1 text-xl font-bold tracking-tight">{pipeline.title}</h1>
          <div className="flex flex-wrap items-center gap-2 text-[13px] text-fg-muted">
            <span className="font-mono">{pipeline.id}</span>
            <span>·</span>
            <span>{pipeline.stateful ? "stateful" : "stateless"}</span>
            <span>·</span>
            <span>
              {def?.modules.length ?? 0} module(s), {def?.tasks.length ?? 0} task(s)
            </span>
            {pipeline.tags.map((t) => (
              <Tag key={t}>{t}</Tag>
            ))}
          </div>
        </div>
        <div className="flex-1" />
        <div className="flex flex-wrap gap-2">
          {active ? (
            <>
              {paused ? (
                <button className="btn btn-primary" onClick={() => control("resume")}>
                  ▶ Resume
                </button>
              ) : (
                <button className="btn" onClick={() => control("pause")}>
                  ⏸ Pause
                </button>
              )}
              <button className="btn btn-danger" onClick={() => control("stop")}>
                ■ Stop
              </button>
              <Link className="btn" to={`/runs/${active.id}`}>
                Open console
              </Link>
            </>
          ) : (
            <>
              <button className="btn btn-primary" onClick={() => start("incremental")} disabled={!pipeline.enabled}>
                ▶ Run
              </button>
              <button className="btn" onClick={() => start("full")} disabled={!pipeline.enabled}>
                Run full
              </button>
              <button className="btn" onClick={() => start("retry-failed")} disabled={!pipeline.enabled}>
                Retry failed
              </button>
            </>
          )}
          <button className="btn" onClick={toggleEnabled}>
            {pipeline.enabled ? "Disable" : "Enable"}
          </button>
        </div>
      </header>

      {pipeline.definition_error ? <Banner>{pipeline.definition_error}</Banner> : null}
      {active ? (
        <Banner tone="info">
          Run #{active.id} is {active.status}
          {active.phase ? ` · ${active.phase}` : ""}
          {active.progress_total ? ` · ${active.progress_done}/${active.progress_total}` : ""} —{" "}
          <Link className="text-brand" to={`/runs/${active.id}`}>
            open the live console
          </Link>
        </Banner>
      ) : null}

      <div className="mb-4 flex flex-wrap gap-0.5 border-b border-ink-600/60">
        {TABS.map((name) => (
          <button
            key={name}
            disabled={name === "entities" && !pipeline.stateful}
            onClick={() => navigate(`/p/${pipeline.id}/${name}`)}
            className={`-mb-px rounded-t-lg border border-b-0 px-3.5 py-2 text-[13px] capitalize disabled:opacity-30 ${
              activeTab === name
                ? "border-ink-600/60 bg-ink-900 text-fg"
                : "border-transparent text-fg-dim hover:text-fg"
            }`}
          >
            {name}
          </button>
        ))}
      </div>

      {activeTab === "overview" ? (
        <Overview
          pipeline={pipeline}
          onRun={runWith}
          onOpenFile={openFile}
          onResetModule={resetModule}
        />
      ) : null}
      {activeTab === "runs" ? (
        <Panel flush>
          <RunTable runs={runs} />
        </Panel>
      ) : null}
      {activeTab === "entities" ? <Entities pipeline={pipeline} /> : null}
      {activeTab === "files" ? (
        <Files pipeline={pipeline} file={editorFile} onSelect={setEditorFile} />
      ) : null}
    </div>
  );
}
