import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api, isActive, wsUrl, type ProcessStats, type Run, type RunEvent, type RunStep } from "../api";
import { Console } from "../components/Console";
import { Banner, Empty, Panel, ProgressBar, StatCard, StatusPill } from "../components/ui";
import { fmtDuration, fmtNumber, fmtTime } from "../lib/format";
import { useApp } from "../lib/store";

const MAX_EVENTS = 6000;

function StepTable({ steps }: { steps: RunStep[] }) {
  if (!steps.length) return <Empty>No steps recorded yet.</Empty>;
  return (
    <table className="w-full text-[13px]">
      <thead>
        <tr>
          <th className="th">Step</th>
          <th className="th">Kind</th>
          <th className="th">Status</th>
          <th className="th num">Selected</th>
          <th className="th num">Processed</th>
          <th className="th num">Skipped</th>
          <th className="th num">Failed</th>
          <th className="th num">Duration</th>
        </tr>
      </thead>
      <tbody>
        {steps.map((step) => (
          <tr key={step.step} title={step.error ?? undefined}>
            <td className="td font-mono">{step.step}</td>
            <td className="td text-fg-muted">
              {step.kind}
              {step.version > 1 ? ` v${step.version}` : ""}
            </td>
            <td className="td">
              <StatusPill status={step.status} />
            </td>
            <td className="td num">{fmtNumber(step.selected)}</td>
            <td className="td num">{fmtNumber(step.processed)}</td>
            <td className="td num">{fmtNumber(step.skipped)}</td>
            <td className={`td num ${step.failed ? "text-err" : ""}`}>{fmtNumber(step.failed)}</td>
            <td className="td num text-fg-muted">{fmtDuration(step.duration_ms)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function Sparkline({ values, color, max }: { values: number[]; color: string; max?: number }) {
  if (values.length < 2) return null;
  const top = max ?? Math.max(...values, 1);
  const step = 100 / (values.length - 1);
  const points = values
    .map((v, i) => `${(i * step).toFixed(2)},${(100 - (v / top) * 100).toFixed(2)}`)
    .join(" ");
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="mt-1 block h-10 w-full">
      <polyline points={points} fill="none" stroke={color} strokeWidth={2} vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

function Resources({ samples, fallback }: { samples: ProcessStats[]; fallback: ProcessStats }) {
  const last = samples[samples.length - 1] ?? fallback;
  if (!last || !Object.keys(last).length) return <Empty>No telemetry for this run.</Empty>;
  const cells: [string, string | number | undefined, number[] | null, string][] = [
    ["Memory MB", last.rss_mb, samples.map((s) => s.rss_mb ?? 0), "#5b8cff"],
    ["CPU %", last.cpu_percent, samples.map((s) => s.cpu_percent ?? 0), "#4dd0e1"],
    ["Peak MB", last.peak_rss_mb, null, ""],
    ["Threads", last.threads, null, ""],
    ["Entities/s", last.entities_per_s, null, ""],
    ["Parallel", last.parallel ?? 1, null, ""],
    ["PID", last.pid, null, ""],
    ["Source", last.backend, null, ""],
  ];
  return (
    <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-8">
      {cells.map(([label, value, series, color]) => (
        <div key={label} className="rounded-lg border border-ink-600/60 bg-ink-800 px-3 py-2">
          <div className="text-[10px] uppercase tracking-[0.08em] text-fg-muted">{label}</div>
          <div className="text-lg font-bold tabular-nums">{value ?? "–"}</div>
          {series ? <Sparkline values={series} color={color} max={label === "CPU %" ? 100 : undefined} /> : null}
        </div>
      ))}
    </div>
  );
}

export default function RunPage() {
  const { runId } = useParams();
  const id = Number(runId);
  const navigate = useNavigate();
  const { toast } = useApp();

  const [run, setRun] = useState<Run | null>(null);
  const [steps, setSteps] = useState<RunStep[]>([]);
  const [events, setEvents] = useState<RunEvent[]>([]);
  const [samples, setSamples] = useState<ProcessStats[]>([]);

  const reload = useCallback(async () => {
    try {
      const fresh = await api.run(id);
      setRun(fresh);
      setSteps(fresh.steps ?? []);
    } catch (err) {
      toast((err as Error).message, "error");
    }
  }, [id, toast]);

  useEffect(() => {
    void reload();
  }, [reload]);

  // Live stream with an HTTP polling fallback if WebSockets are unavailable.
  useEffect(() => {
    if (!Number.isFinite(id)) return;
    let opened = false;
    let closed = false;
    let poll: ReturnType<typeof setInterval> | undefined;

    const startPolling = () => {
      if (poll || closed) return;
      const tick = async () => {
        try {
          const [console_, fresh] = await Promise.all([api.console(id), api.run(id)]);
          setEvents(console_.events.filter((e) => e.kind !== "resource"));
          setSamples(
            console_.events.filter((e) => e.kind === "resource").slice(-120) as unknown as ProcessStats[],
          );
          setRun(fresh);
          setSteps(fresh.steps ?? []);
          if (!isActive(fresh.status) && poll) {
            clearInterval(poll);
            poll = undefined;
          }
        } catch {
          /* keep trying */
        }
      };
      void tick();
      poll = setInterval(tick, 1500);
    };

    let socket: WebSocket | null = null;
    try {
      socket = new WebSocket(wsUrl(`/api/ws/runs/${id}`));
    } catch {
      startPolling();
    }

    if (socket) {
      socket.onopen = () => {
        opened = true;
      };
      socket.onerror = () => !opened && startPolling();
      socket.onclose = () => !opened && startPolling();
      socket.onmessage = (message) => {
        const data = JSON.parse(message.data) as RunEvent;
        if (data.kind === "snapshot") {
          const all = data.events ?? [];
          setEvents(all.filter((e) => e.kind !== "resource"));
          setSamples(all.filter((e) => e.kind === "resource") as unknown as ProcessStats[]);
          if (data.run) setRun(data.run);
          return;
        }
        if (data.kind === "resource") {
          setSamples((current) => [...current, data as unknown as ProcessStats].slice(-120));
          return;
        }
        if (data.kind === "run_finished") {
          void reload();
          return;
        }
        setEvents((current) => {
          const next = [...current, data];
          return next.length > MAX_EVENTS ? next.slice(next.length - MAX_EVENTS) : next;
        });
        if (data.kind === "step_start" || data.kind === "step_end") {
          api.steps(id).then(setSteps).catch(() => undefined);
        }
        if (data.kind === "progress") {
          setRun((current) =>
            current
              ? { ...current, progress_done: data.done ?? 0, progress_total: data.total ?? 0, phase: data.step ?? null }
              : current,
          );
        }
        if (data.kind === "status" && data.status) {
          const mapping: Record<string, Run["status"]> = {
            paused: "paused",
            running: "running",
            stopping: "stopping",
          };
          const mapped = mapping[data.status];
          if (mapped) setRun((current) => (current ? { ...current, status: mapped } : current));
        }
      };
    }

    return () => {
      closed = true;
      if (poll) clearInterval(poll);
      socket?.close();
    };
  }, [id, reload]);

  const control = async (action: "pause" | "resume" | "stop") => {
    try {
      const result = await api.control(id, action);
      if (action === "resume" && result.id !== id) navigate(`/runs/${result.id}`);
      else {
        toast(`Run ${action} requested`);
        setTimeout(() => void reload(), 500);
      }
    } catch (err) {
      toast((err as Error).message, "error");
    }
  };

  if (!run) return <div className="px-6 py-8 text-fg-muted">Loading run #{runId}…</div>;

  const live = samples[samples.length - 1] ?? {};
  const metrics = { ...(run.metrics ?? {}) };
  if (isActive(run.status)) {
    for (const key of ["processed", "skipped", "failed", "entities_total"] as const) {
      if (live[key] !== undefined) metrics[key] = live[key];
    }
  }
  const counters: Record<string, number> = metrics.counters ?? {};
  const active = isActive(run.status);
  const paused = run.status === "paused" || run.status === "pausing";
  const pct = run.progress_total ? Math.round((run.progress_done / run.progress_total) * 100) : null;

  return (
    <div className="max-w-[1400px] px-6 pb-10 pt-6">
      <header className="mb-5 flex flex-wrap items-start gap-4">
        <div>
          <h1 className="mb-1 flex items-center gap-3 text-xl font-bold tracking-tight">
            Run #{run.id} <StatusPill status={run.status} />
          </h1>
          <p className="text-[13px] text-fg-muted">
            <Link className="text-brand" to={`/p/${run.pipeline_id}`}>
              {run.pipeline_id}
            </Link>{" "}
            · mode {run.mode} · started {fmtTime(run.started_at)}
            {run.parent_run_id ? (
              <>
                {" "}
                · resumed from{" "}
                <Link className="text-brand" to={`/runs/${run.parent_run_id}`}>
                  #{run.parent_run_id}
                </Link>
              </>
            ) : null}
          </p>
        </div>
        <div className="flex-1" />
        <div className="flex gap-2">
          {active ? (
            <>
              {paused ? (
                <button className="btn btn-primary" onClick={() => control("resume")}>
                  ▶ Resume
                </button>
              ) : (
                <button className="btn" onClick={() => control("pause")}>
                  ⏸ Pause
                </button>
              )}
              <button className="btn btn-danger" onClick={() => control("stop")}>
                ■ Stop
              </button>
            </>
          ) : (
            <button className="btn btn-primary" onClick={() => control("resume")}>
              ▶ Resume in a new run
            </button>
          )}
        </div>
      </header>

      {run.error ? <Banner>{run.error}</Banner> : null}

      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard
          label="Duration"
          value={
            <span className="text-base">
              {fmtDuration(run.duration_ms ?? (run.started_at ? Date.now() - new Date(run.started_at).getTime() : null))}
            </span>
          }
        />
        <StatCard label="Processed" value={fmtNumber(metrics.processed ?? 0)} />
        <StatCard label="Skipped" value={fmtNumber(metrics.skipped ?? 0)} />
        <StatCard label="Failed" value={fmtNumber(metrics.failed ?? 0)} tone={metrics.failed ? "err" : undefined} />
        <StatCard label="Entities" value={fmtNumber(metrics.entities_total ?? 0)} />
        {pct !== null ? (
          <StatCard
            label={`Progress${run.phase ? ` · ${run.phase}` : ""}`}
            value={<span className="text-base">{`${run.progress_done}/${run.progress_total}`}</span>}
            hint={<ProgressBar value={pct} />}
          />
        ) : null}
      </div>

      <Panel title="Process & resources">
        <Resources samples={samples} fallback={run.stats ?? {}} />
      </Panel>

      <Panel title="Steps" flush>
        <StepTable steps={steps} />
      </Panel>

      {Object.keys(counters).length ? (
        <Panel title="Counters">
          <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {Object.entries(counters).map(([key, value]) => (
              <StatCard key={key} label={key} value={<span className="text-base">{fmtNumber(value)}</span>} />
            ))}
          </div>
        </Panel>
      ) : null}

      <Panel title="Console" flush>
        <Console events={events} downloadUrl={`/api/runs/${run.id}/log/download`} />
      </Panel>
    </div>
  );
}
