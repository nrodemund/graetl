import { useEffect, useState } from "react";
import { api, type Run } from "../api";
import { RunTable } from "../components/RunTable";
import { Panel } from "../components/ui";
import { useApp } from "../lib/store";

export default function RunsPage() {
  const { revision, toast } = useApp();
  const [runs, setRuns] = useState<Run[]>([]);

  useEffect(() => {
    api.runs({ limit: 100 }).then(setRuns).catch((err) => toast((err as Error).message, "error"));
  }, [revision, toast]);

  return (
    <div className="max-w-[1400px] px-6 pb-10 pt-6">
      <header className="mb-5">
        <h1 className="mb-1 text-xl font-bold tracking-tight">Runs</h1>
        <p className="text-[13px] text-fg-muted">Every execution, newest first.</p>
      </header>
      <Panel flush>
        <RunTable runs={runs} showPipeline />
      </Panel>
    </div>
  );
}
