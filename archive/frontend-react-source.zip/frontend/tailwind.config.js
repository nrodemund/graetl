/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          950: "#0a0e16",
          900: "#111825",
          800: "#161f30",
          700: "#1c2740",
          600: "#223049",
          500: "#2d3e5c",
        },
        fg: { DEFAULT: "#e7edf7", dim: "#9aa8bf", muted: "#6b7a94" },
        brand: { DEFAULT: "#5b8cff", soft: "#5b8cff22" },
        ok: "#3ddc97",
        warn: "#ffc46b",
        err: "#ff6b6b",
        run: "#4dd0e1",
        pause: "#b794f6",
      },
      fontFamily: {
        mono: ["ui-monospace", "JetBrains Mono", "SF Mono", "Menlo", "Consolas", "monospace"],
      },
      keyframes: {
        pulseDot: {
          "0%": { boxShadow: "0 0 0 0 rgba(77,208,225,.45)" },
          "70%": { boxShadow: "0 0 0 7px rgba(77,208,225,0)" },
          "100%": { boxShadow: "0 0 0 0 rgba(77,208,225,0)" },
        },
      },
      animation: { pulseDot: "pulseDot 1.6s infinite" },
    },
  },
  plugins: [],
};
