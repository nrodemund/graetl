import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

const backend = process.env.GRAETL_API ?? "http://127.0.0.1:8777";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5273,
    proxy: {
      "/api": { target: backend, changeOrigin: true, ws: true },
    },
  },
  build: {
    outDir: "dist",
    emptyOutDir: true,
  },
});
